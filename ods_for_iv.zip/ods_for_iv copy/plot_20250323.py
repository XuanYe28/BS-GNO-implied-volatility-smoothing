import os
from pathlib import Path
from code_20250322 import GNO
from code_20250322 import GNOLayer
import pandas as pd
import matplotlib.pyplot as plt
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['savefig.bbox'] = 'tight'
import torch

from code_20250322 import WRDSOptionsDataset
from code_20250322 import Loss
from code_20250322 import GNOOptionsDataset
from code_20250322 import load_checkpoint
from code_20250322 import create_gno
from code_20250322 import NonlinearKernelTransformWithSkip

def load_checkpoint(path: str, device=None):
    model = create_gno().to(device)
    optimizer = torch.optim.AdamW(model.parameters())
    checkpoint = torch.load(path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint['model'])
    optimizer.load_state_dict(checkpoint['optimizer'])
    return model, optimizer


# ==== 主流程 ====

os.environ['OPDS_CACHE_DIR'] = os.path.expanduser('~/.cache/opds')
os.environ['OPDS_WRDS_DATA_DIR'] = os.path.abspath("../ods_for_iv/volatility_smoothing/data/wrds/spx")

spx_dataset = WRDSOptionsDataset(force_reprocess=False)
spx_gno_dataset = GNOOptionsDataset(spx_dataset, subsample=False)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print("init data done")
path = "./MY_CHECKPOINTS/checkpoints/local_checkpoint_0.pt"

gno, _ = load_checkpoint(path, device=device)
print("init checkpoints done")
step_r = 0.05
step_z = 0.01
loss = Loss(step_r=step_r, step_z=step_z)
print("start evaluate")

_, _, _, data_list = loss.evaluate(gno, spx_gno_dataset, device=device, return_data=True)

for i, data in enumerate(data_list[:5]):
    fig, axs = loss.plot_example(gno, data, figsize=(14, 20))
    fig.suptitle(f'Example: quote_datetime={data.quote_datetime.date()}', fontsize=16)
    plt.show()
    plt.close(fig)
